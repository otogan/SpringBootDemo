package com.onurtogan.demo.simpledemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleSpringBootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleSpringBootDemoApplication.class, args);
	}

}
