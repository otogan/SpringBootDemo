package com.onurtogan.demo.simpledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleSpringBootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
